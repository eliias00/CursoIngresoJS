function mostrar()
{
    var hora = document.getElementById('hora').value;
    switch(hora)
    { case "7":
      case "8":
      case "9":
      case "10":
      case "11":
     alert("Es de mañana")
     break;
    }
}
//FIN DE LA FUNCIÓN