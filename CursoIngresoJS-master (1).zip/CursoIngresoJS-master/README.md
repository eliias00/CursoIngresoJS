# CursoIngresoJS
Curso de ingreso con JavaScript

ejercitación y TP para rendir el examen de ingreso 
<h1>UTNFRA</h1>
<h3>Tecnico superior en programación</h3>


http://octaviovillegas.github.io/CursoIngresoJS/
