function mostrar()
{
	var num = prompt("ingrese un número entre 0 y 10.");

	while(!(num>=0 && num<=9))
	{
		num=prompt("ingrese el numero pedido")
	}
alert("bien hecho")

}//FIN DE LA FUNCIÓN