function mostrar()
{var cont=10
   while(cont>0) 
	{ 
	alert("numero: " + cont);
	cont--
 }

}//FIN DE LA FUNCIÓN