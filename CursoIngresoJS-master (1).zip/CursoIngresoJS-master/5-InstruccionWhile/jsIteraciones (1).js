function mostrar()
{var cont =0
	while( cont<10)
	{
		cont++
		alert ("numero: " + cont);
	}
	

}//FIN DE LA FUNCIÓN