function mostrar()
{ var clave = prompt("ingrese el número clave.");

while(clave!= "utn750")
{
clave=prompt("vuelva a ingresar la clave")
}

alert("bien hecho")



}
//FIN DE LA FUNCIÓN
