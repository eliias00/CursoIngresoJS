function mostrar()
{var edad;
    edad=document.getElementById("edad").value;
    if(edad>=18)
    {
alert("eres mayor de edad!!!!");
    }




}//FIN DE LA FUNCIÓN