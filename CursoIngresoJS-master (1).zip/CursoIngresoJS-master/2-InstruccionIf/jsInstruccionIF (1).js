function mostrar()
{var edad;
    edad=document.getElementById("edad").value;
if(edad==15)
{
    alert("niña bonita");
}


}//FIN DE LA FUNCIÓN