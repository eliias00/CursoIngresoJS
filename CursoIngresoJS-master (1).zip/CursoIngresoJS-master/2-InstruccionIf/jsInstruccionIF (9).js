function mostrar()
{
	var numero;
    numero= Math.round(Math.random()*10);
    alert("numero aleatorio: " + numero);


}

//FIN DE LA FUNCIÓN
