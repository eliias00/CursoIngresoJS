
function mostrar()
{var ancho=parseInt(prompt("ingrese ancho"))
 var largo=parseInt(prompt("ingrese largo"))
 var pari

 peri= ancho*2 + largo*2
 alert(" el perimetro es de: " + peri )

}
