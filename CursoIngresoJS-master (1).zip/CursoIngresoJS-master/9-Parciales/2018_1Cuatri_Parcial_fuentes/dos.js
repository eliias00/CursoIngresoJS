function mostrar()
{
    var nombre=document.getElementById("elNombre").value
    var localidad=document.getElementById("laLocalidad").value

    alert(" usted es: " + nombre + " y vive en la localidad de: " + localidad)

}
