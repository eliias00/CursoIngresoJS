function mostrar()
{
    var nom=document.getElementById("elNombre").value
    var loc=document.getElementById("laLocalidad").value
    alert("usted es: " + nom + " y vive en la localidad: " + loc)
  
}
