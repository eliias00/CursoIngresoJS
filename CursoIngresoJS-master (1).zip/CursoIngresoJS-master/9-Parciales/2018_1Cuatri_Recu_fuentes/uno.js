
function mostrar()
{
    var base = parseInt(prompt("ingrese base"));
    var altura =parseInt(prompt("ingrese altura"));
    var supe
    var peri
    
    supe=(base*altura)/2
    peri= base*3
    alert("la superficie es: " + supe + " y el perimetro es: " + peri)

}
